import os
# comment
x = 1

print(x)
