// crate docs
pub fn main() {}

// trailing comment
