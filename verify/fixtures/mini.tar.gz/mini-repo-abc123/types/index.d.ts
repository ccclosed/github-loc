export const x: number;
